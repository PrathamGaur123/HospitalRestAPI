from flask import Flask, request, jsonify
from flask_restful import Resource, Api
import pymysql

app = Flask(__name__)
api = Api(app)

con=pymysql.connect(host='bjdnzwywx4yuwlv2yvqn-mysql.services.clever-cloud.com',user='uryhne0taq31lhab',password='9ktaVYjniKvGj207ouvQ',database='bjdnzwywx4yuwlv2yvqn')
curs = con.cursor()

class AllDoctors(Resource):
    def get(self):
        curs.execute("select * from doctors")
        data = curs.fetchall()
        dic = {}
        if data:
            dic['status'] = 'Data Found'
            dic['All Doctors'] = data
        else:
            dic['status'] = 'Data Not Found'
        return dic

class AllPatients(Resource):
    def get(self):
        curs.execute("select * from patients")
        data = curs.fetchall()
        dic = {}
        if data:
            dic['status'] = 'Data Found'
            dic['All Patients'] = data
        else:
            dic['status'] = 'Data Not Found'
        return dic

@app.route('/patient/add', methods=['POST'])
def newpatient():
    patid = int(request.form.get("patno"))
    patnm = request.form.get("patnm")
    age = int(request.form.get("age"))
    gender = request.form.get("gender")
    illness = request.form.get("illness")
    docid = int(request.form.get("docid"))
    dic = {}
    
    try:
        curs.execute("insert into patients values(%d, '%s', %d, '%s', '%s', %d)" %(patid,patnm,age,gender,illness,docid))
        con.commit()
        dic['status'] = 'success'
    except:
        dic['status'] = 'failed'
    return dic

class SearchPatient(Resource):
    def get(self, patno):
        patid = int(patno)
        curs.execute("select * from patients where patno=%d" %patid)
        rec = curs.fetchone()
        dic = {}
        if rec:
            dic['status'] = 'Data Found'
            dic['patno'] = rec[0]
            dic['patnm'] = rec[1]
            dic['age'] = rec[2]
            dic['gender'] = rec[3]
            dic['illness'] = rec[3]
            dic['docid'] = rec[3]
        else:
            dic['status'] = 'Data Not Found'
        return dic

class SearchDoctor(Resource):
    def get(self, docid):
        docno = int(docid)
        curs.execute("select * from doctors where docid=%d" %docno)
        rec = curs.fetchone()
        dic = {}
        if rec:
            dic['status'] = 'Data Found'
            dic['docid'] = rec[0]
            dic['docnm'] = rec[1]
            dic['specialization'] = rec[2]
            dic['experience'] = rec[3]
        else:
            dic['status'] = 'Data Not Found'
        return dic

@app.route('/doctor/<int:docid>/experience', methods=['PUT'])
def modify_experience(docid):
    newexp = request.json.get('experience')
    dic = {}

    try:
        curs.execute("select * from doctors where docid=%d" %docid)
        data = curs.fetchone()
        if data:
            curs.execute("update doctors set experience=%d where docid=%d" %(newexp,docid))
            con.commit()
            dic['status'] = 'success'
    except:
        dic['status'] = 'failed'
    return dic

class PatientsName(Resource):
    def get(self):
        curs.execute("select patients.patnm, patients.illness, doctors.docnm from patients inner join doctors on patients.docid=doctors.docid")
        data = curs.fetchall()
        dic = {}
        if data:
            dic['status'] = 'Data Found'
            dic['All Patients'] = data
        else:
            dic['status'] = 'Data Not Found'
        return dic

api.add_resource(AllDoctors, "/alldoctors")
api.add_resource(AllPatients, "/allpatients")
api.add_resource(SearchPatient, "/searchpatient/<patno>")
api.add_resource(SearchDoctor, "/searchdoctor/<docid>")
api.add_resource(PatientsName, "/patientsname")
app.run(debug=True)